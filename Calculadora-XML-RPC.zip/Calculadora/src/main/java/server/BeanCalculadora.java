package server;

import java.util.Date;

public class BeanCalculadora {
    private String operacion;
    private int num1;
    private int num2;
    private double resultado;
    private Date fecha;

    public BeanCalculadora(){}
    public BeanCalculadora(String operacion, int num1, int num2, int resultado, Date fecha){
        this.operacion = operacion;
        this.num1 = num1;
        this.num2 = num2;
        this.resultado = resultado;
        this.fecha = fecha;
    }

    public void setOperacion(String operacion){this.operacion = operacion;}
    public void setNum1(int num1){this.num1 = num1;}
    public void setNum2(int num2){this.num2 = num2;}
    public void setResultado(double resultado){this.resultado = resultado;}
    public void setFecha(Date fecha){this.fecha = fecha;}

    public String getOperacion(){return operacion;}
    public int getnum1(){return num1;}
    public int getNum2(){return num2;}
    public double getResultado(){return resultado;}
    public Date getFecha(){return fecha;}
}
