package server;

import utils.MySQLConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class DaoCalculadora {
    public boolean saveCal(String operacion,int num1, int num2, double resultado){
        boolean result = false;
        try(Connection connection = MySQLConnection.getConnection();
            PreparedStatement pstm = connection.prepareStatement(
                    "insert into operations (operacion,num1,num2,resultado) values (?,?,?)")){
            pstm.setString(1,operacion);
            pstm.setInt(2,num1);
            pstm.setInt(3,num2);
            pstm.setDouble(4,resultado);
            result =pstm.executeUpdate()==1;
        }catch (Exception e){
            e.printStackTrace();
        }
        return result;
    }
    
    public ArrayList<BeanCalculadora>historial(){
        ArrayList<BeanCalculadora> list =new ArrayList<>();
        try{
            Connection connection = MySQLConnection.getConnection();
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery("select * from operations");
            while (rs.next()){
                BeanCalculadora beanCalculadora = new BeanCalculadora();
                beanCalculadora.setOperacion(rs.getString("operacion"));
                beanCalculadora.setNum1(rs.getInt("num1"));
                beanCalculadora.setNum2(rs.getInt("num2"));
                beanCalculadora.setResultado(rs.getDouble("resultado"));
                beanCalculadora.setFecha(rs.getDate("fecha"));
                list.add(beanCalculadora);
            }
            rs.close();
            connection.close();
            statement.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }
}
