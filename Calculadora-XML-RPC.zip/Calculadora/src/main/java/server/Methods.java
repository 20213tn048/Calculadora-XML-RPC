package server;

import java.util.ArrayList;

public class Methods {
    public Methods(){}

    public double suma(int num1, int num2){
        DaoCalculadora daoCalculadora = new DaoCalculadora();
        boolean result = daoCalculadora.saveCal("Suma",num1,num2,num1+num2);
        return num1+num2;
    }
    public double resta(int num1,int num2){
        DaoCalculadora daoCalculadora = new DaoCalculadora();
        boolean result = daoCalculadora.saveCal("Resta",num1,num2,num1-num2);
        return num1-num2;
    }
    public double multi(int num1,int num2){
        DaoCalculadora daoCalculadora = new DaoCalculadora();
        boolean result = daoCalculadora.saveCal("Multiplicación",num1,num2,num1*num2);
        return num1*num2;
    }
    public double div(int num1, int num2){
        DaoCalculadora daoCalculadora = new DaoCalculadora();
        boolean result = daoCalculadora.saveCal("División",num1,num2,num1/num2);
        return num1/num2;
    }
    public double pow(int num1, int num2){
        DaoCalculadora daoCalculadora = new DaoCalculadora();
        boolean result = daoCalculadora.saveCal("Potencia",num1,num2,Math.pow(num1,num2));
        return Math.pow(num1,num2);
    }
    public double sqrt(int num1, int num2){
        DaoCalculadora daoCalculadora = new DaoCalculadora();
        boolean result = daoCalculadora.saveCal("Raíz",num1,num2,Math.pow(num1,1/num2));
        return Math.pow(num1,1/num2);
    }
    public String historial(int count){
        DaoCalculadora daoCalculadora = new DaoCalculadora();
        ArrayList<BeanCalculadora> list =daoCalculadora.historial();
        if(count == list.size()){
            return "";
        }else{
            return list.get(count).getOperacion()+"||"+list.get(count).getnum1()+"||"+list.get(count).getNum2()+"||"+
                    list.get(count).getResultado()+"||"+list.get(count).getFecha();
        }
    }
}
