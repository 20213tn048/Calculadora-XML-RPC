package client;

import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class CalculadoraRPC {
    public static void main(String[] args) throws MalformedURLException {
        Scanner entrada = new Scanner(System.in);
        XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();
        config.setServerURL(new URL("http://localhost:1200"));
        XmlRpcClient client = new XmlRpcClient();
        client.setConfig(config);
        String opcion = "", num1 = "", num2 = "";
        int aux1 = 0;
        int aux2 = 0;
        double result;
        Object[] value;
        do {
            System.out.println("CALCULADORA\n" +
                    "0.Salir\n" +
                    "1.Suma\n" +
                    "2.Resta\n" +
                    "3.Multiplicación\n" +
                    "4.División\n" +
                    "5.Elevación\n" +
                    "6.Radicación\n" +
                    "7.Historial");
            System.out.print("Escriba el número de la opción que desea realizar: ");
            opcion = entrada.next();
            if (isNumber(opcion)) {
                switch (Integer.parseInt(opcion)) {
                    case 0:
                        break;
                    case 1:
                        do {
                            System.out.print("Ingrese un valor entero: ");
                            num1 = entrada.next();
                            if (!isNumber(num1)) {
                                System.out.println("Dato inválido, ingrese un número natural");
                            } else {
                                aux1 = Integer.parseInt(num1);
                            }
                        } while (!isNumber(num1));
                        do {
                            System.out.print("Ingrese un valor entero: ");
                            num2 = entrada.next();
                            if (!isNumber(num2)) {
                                System.out.println("Dato inválido, ingrese un número natural");
                            } else {
                                aux2 = Integer.parseInt(num2);
                            }
                        } while (!isNumber(num2));

                        value = new Object[2];
                        value[0] = aux1;
                        value[1] = aux2;

                        try {
                            result = (Double) client.execute("Methods.suma", value);
                            System.out.println(num1 + " + " + num2 + " = " + result + "\n");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        break;
                    case 2:
                        do {
                            System.out.print("Ingrese un valor entero: ");
                            num1 = entrada.next();
                            if (!isNumber(num1)) {
                                System.out.println("Dato inválido, ingrese un número natural");
                            } else {
                                aux1 = Integer.parseInt(num1);
                            }
                        } while (!isNumber(num1));
                        do {
                            System.out.print("Ingrese un valor entero: ");
                            num2 = entrada.next();
                            if (!isNumber(num2)) {
                                System.out.println("Dato inválido, ingrese un número natural");
                            } else {
                                aux2 = Integer.parseInt(num2);
                            }
                        } while (!isNumber(num2));

                        value = new Object[2];
                        value[0] = aux1;
                        value[1] = aux2;

                        try {
                            result = (Double) client.execute("Methods.resta", value);
                            System.out.println(num1 + " - " + num2 + " = " + result + "\n");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        break;
                    case 3:
                        do {
                            System.out.print("Escribe un valor entero: ");
                            num1 = entrada.next();
                            if (!isNumber(num1)) {
                                System.out.println("Dato inválido, ingrese un número natural");
                            } else {
                                aux1 = Integer.parseInt(num1);
                            }
                        } while (!isNumber(num1));
                        do {
                            System.out.print("Escribe un valor entero: ");
                            num2 = entrada.next();
                            if (!isNumber(num2)) {
                                System.out.println("Dato inválido, ingrese un número natural");
                            } else {
                                aux2 = Integer.parseInt(num2);
                            }
                        } while (!isNumber(num2));

                        value = new Object[2];
                        value[0] = aux1;
                        value[1] = aux2;

                        try {
                            result = (Double) client.execute("Methods.multi", value);
                            System.out.println(num1 + " * " + num2 + " = " + result);
                        } catch (Exception e) {
                            e.printStackTrace();

                        }
                        break;
                    case 4:
                        do {
                            System.out.print("Escribe un valor entero: ");
                            num1 = entrada.next();
                            if (!isNumber(num1)) {
                                System.out.println("Dato inválido, ingrese un número natural");
                            } else {
                                aux1 = Integer.parseInt(num1);
                            }
                        } while (!isNumber(num1));
                        do {
                            System.out.print("Escribe un valor entero: ");
                            num2 = entrada.next();
                            if (!isNumber(num2)) {
                                System.out.println("Dato inválido, ingrese un número natural");
                            } else {
                                if (num2.equals("0")) {
                                    System.out.println("Cualquier número dividido entre 0 es un indeterminante, ingrese un número mayor a 0");
                                } else {
                                    aux2 = Integer.parseInt(num2);
                                }
                            }
                        } while (!isNumber(num2));

                        value = new Object[2];
                        value[0] = aux1;
                        value[1] = aux2;

                        try {
                            result = (Double) client.execute("Methods.div", value);
                            System.out.println(num1 + " / " + num2 + " = " + result);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    case 5:
                        do {
                            System.out.print("Escriba un valor entero: ");
                            num1 = entrada.next();
                            if (!isNumber(num1)) {
                                System.out.println("Dato inválido, ingrese un número natural");
                            } else {
                                aux1 = Integer.parseInt(num1);
                            }
                        } while (!isNumber(num1));
                        do {
                            System.out.print("Escriba un valor entero: ");
                            num2 = entrada.next();
                            if (!isNumber(num2)) {
                                System.out.println("Dato inválido, ingrese un número natural");
                            } else {
                                aux2 = Integer.parseInt(num2);
                            }
                        } while (!isNumber(num2));

                        value = new Object[2];
                        value[0] = aux1;
                        value[1] = aux2;

                        try {
                            result = (Double) client.execute("Methods.pow", value);
                            System.out.println(num1 + " ^ " + num2 + " = " + result);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    case 6:
                        do {
                            System.out.print("Escriba un valor entero: ");
                            num1 = entrada.next();
                            if (!isNumber(num1)) {
                                System.out.println("Dato inválido, ingrese un número natural");
                            } else {
                                aux1 = Integer.parseInt(num1);
                            }
                        } while (!isNumber(num1));
                        do {
                            System.out.print("Escriba un valor entero: ");
                            num2 = entrada.next();
                            if (!isNumber(num2)) {
                                System.out.println("Dato inválido, ingrese un número natural");
                            } else {
                                aux2 = Integer.parseInt(num2);
                            }
                        } while (!isNumber(num2));

                        value = new Object[2];
                        value[0] = aux1;
                        value[1] = aux2;

                        try {
                            result = (Double) client.execute("Methods.sqrt", value);
                            System.out.println("Raíz de " + num1 + " con índice " + num2 + " = " + result);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    case 7:
                        value = new Object[1];
                        int contador = 0;
                        String cadena ="";
                        do{
                            value[0]=contador;
                            try{
                                cadena = (String) client.execute("Methods.historial",value);
                                System.out.println(cadena);
                                contador++;
                            }catch (Exception e){
                                e.printStackTrace();
                            }
                        }while (!(cadena.equals("")));
                        break;
                    default:
                        System.out.println("Dato inválido. Ingrese un dato válido");
                        break;
                }
            }
        } while (!opcion.equals("0"));
    }

    public static boolean isNumber(String number) {
        try {
            int num = Integer.parseInt(number);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
